//John Aston Adams
//11/7/22

package HomeworkUnit2;


public class ArrayOfHope {
    public static void main(String[] args){
        char[] ch = new char[26];
        for (int i = 0; i < ch.length; i++) {
            ch[i] = (char) (i + 65);
        }
        for (int j = 0; j < ch.length; j++){
            System.out.print(ch[j] + ", ");
        }
    }
}


